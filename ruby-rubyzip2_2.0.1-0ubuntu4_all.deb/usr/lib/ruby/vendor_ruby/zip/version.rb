module Zip
  VERSION = '2.0.1'
end
