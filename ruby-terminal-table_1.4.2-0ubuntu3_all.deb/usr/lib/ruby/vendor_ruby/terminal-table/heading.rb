
module Terminal
  class Table
    class Heading < Cell
      def initialize width, params
        super
      end
    end
  end
end