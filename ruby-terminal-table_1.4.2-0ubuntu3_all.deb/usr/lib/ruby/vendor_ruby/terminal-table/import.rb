
require 'terminal-table'

include Terminal::Table::TableHelper
