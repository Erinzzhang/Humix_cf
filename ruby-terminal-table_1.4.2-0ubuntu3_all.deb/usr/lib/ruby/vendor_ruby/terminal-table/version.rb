
module Terminal
  class Table
    VERSION = '1.4.2'
  end
end