module VMC; end

require 'vmc/client'
