apt-get install openjdk-6-jdk maven2
mvn clean package
cd target
vmc push
