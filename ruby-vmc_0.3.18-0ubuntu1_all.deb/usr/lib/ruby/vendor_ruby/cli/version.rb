module VMC
  module Cli
    # This version number is used as the RubyGem release version.
    # The internal VMC version number is VMC::VERSION.
    VERSION = '0.3.18'
  end
end
